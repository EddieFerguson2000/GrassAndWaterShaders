// Application.h
#ifndef _APP1_H
#define _APP1_H

// Includes
#include "DXF.h"	// include dxframework
#include "GrassShader.h"
#include "SevenPointMesh.h"
#include "PerlinNoise.h"
#include "Island.h"

class App1 : public BaseApplication
{
public:

	App1();
	~App1();
	void init(HINSTANCE hinstance, HWND hwnd, int screenWidth, int screenHeight, Input* in, bool VSYNC, bool FULL_SCREEN);

	bool frame();

protected:
	bool render();
	void gui();

private:
	Island* island;

	/*GrassShader* grassShader;
	SevenPointMesh* spm;
	PointMesh* mesh;
	PerlinNoise* pn;
	PlaneMesh* planeMesh;
	SphereMesh* sphereMesh;

	float randGrassX[9999];
	float randGrassY[9999];
	float x, y, intensity;
	float windStrength, windDirection, xSpd, ySpd, windX, windY;
	int randX, randY;
	float time;
	int amountOfGrass;*/

};

#endif