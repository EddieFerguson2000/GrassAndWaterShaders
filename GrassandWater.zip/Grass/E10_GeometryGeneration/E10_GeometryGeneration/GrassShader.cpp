// geometry shader.cpp
#include "GrassShader.h"

GrassShader::GrassShader(ID3D11Device* device, HWND hwnd) : BaseShader(device, hwnd)
{
	initShader(L"triangle_vs.cso", L"triangle_gs.cso", L"triangle_ps.cso");
}

GrassShader::~GrassShader()
{
	// Release the sampler state.
	if (sampleState)
	{
		sampleState->Release();
		sampleState = 0;
	}

	// Release the matrix constant buffer.
	if (matrixBuffer)
	{
		matrixBuffer->Release();
		matrixBuffer = 0;
	}

	if (windBuffer)
	{
		windBuffer->Release();
		windBuffer = 0;
	}

	if (noiseBuffer)
	{
		noiseBuffer->Release();
		noiseBuffer = 0;
	}

	if (camBuffer)
	{
		camBuffer->Release();
		camBuffer = 0;
	}

	// Release the layout.
	if (layout)
	{
		layout->Release();
		layout = 0;
	}

	//Release base shader components
	BaseShader::~BaseShader();
}

void GrassShader::initShader(const wchar_t* vsFilename, const wchar_t* psFilename)
{

	

	// Load (+ compile) shader files
	loadVertexShader(vsFilename);
	loadPixelShader(psFilename);

	// Setup the description of the dynamic matrix constant buffer that is in the vertex shader.
	D3D11_BUFFER_DESC matrixBufferDesc;
	matrixBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	matrixBufferDesc.ByteWidth = sizeof(MatrixBufferType);
	matrixBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	matrixBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	matrixBufferDesc.MiscFlags = 0;
	matrixBufferDesc.StructureByteStride = 0;
	// Create the constant buffer pointer so we can access the vertex shader constant buffer from within this class.
	renderer->CreateBuffer(&matrixBufferDesc, NULL, &matrixBuffer);

	// Setup wind buffer
	D3D11_BUFFER_DESC windBufferDesc;

	windBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	windBufferDesc.ByteWidth = sizeof(Wind);
	windBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	windBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	windBufferDesc.MiscFlags = 0;
	windBufferDesc.StructureByteStride = 0;
	renderer->CreateBuffer(&windBufferDesc, NULL, &windBuffer);

	// Setup wind buffer
	D3D11_BUFFER_DESC noiseBufferDesc;

	noiseBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	noiseBufferDesc.ByteWidth = sizeof(NoiseValues);
	noiseBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	noiseBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	noiseBufferDesc.MiscFlags = 0;
	noiseBufferDesc.StructureByteStride = 0;
	renderer->CreateBuffer(&noiseBufferDesc, NULL, &noiseBuffer);

	// Setup wind buffer
	D3D11_BUFFER_DESC camBufferDesc;

	camBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	camBufferDesc.ByteWidth = sizeof(CamBuff);
	camBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	camBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	camBufferDesc.MiscFlags = 0;
	camBufferDesc.StructureByteStride = 0;
	renderer->CreateBuffer(&camBufferDesc, NULL, &camBuffer);

}

void GrassShader::initShader(const wchar_t* vsFilename, const wchar_t* gsFilename, const wchar_t* psFilename)
{
	// InitShader must be overwritten and it will load both vertex and pixel shaders + setup buffers
	initShader(vsFilename, psFilename);

	// Load other required shaders.
	loadGeometryShader(gsFilename);
}


void GrassShader::setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX& world, const XMMATRIX& view, const XMMATRIX& projection, ID3D11ShaderResourceView* texture, Wind windVals, ID3D11ShaderResourceView* height, ID3D11ShaderResourceView* blue, XMFLOAT3 camPos, XMFLOAT3 camRot, NoiseValues noiseVals)
{
	D3D11_MAPPED_SUBRESOURCE mappedResource;
	MatrixBufferType* dataPtr;
	Wind* windPtr;
	NoiseValues* noisePtr;
	CamBuff* camPtr;

	// Transpose the matrices to prepare them for the shader.
	XMMATRIX tworld = XMMatrixTranspose(world);
	XMMATRIX tview = XMMatrixTranspose(view);
	XMMATRIX tproj = XMMatrixTranspose(projection);

	deviceContext->Map(matrixBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	dataPtr = (MatrixBufferType*)mappedResource.pData;
	dataPtr->world = tworld;// worldMatrix;
	dataPtr->view = tview;
	dataPtr->projection = tproj;
	deviceContext->Unmap(matrixBuffer, 0);
	deviceContext->GSSetConstantBuffers(0, 1, &matrixBuffer);

	deviceContext->Map(windBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	windPtr = (Wind*)mappedResource.pData;

	windPtr->grassDisplacement = windVals.grassDisplacement;
	windPtr->windFrequency = windVals.windFrequency;
	windPtr->dt = windVals.dt;
	windPtr->x = windVals.x;
	windPtr->y = windVals.y;
	windPtr->ballX = windVals.ballX;
	windPtr->ballY = windVals.ballY;
	windPtr->windX = windVals.windX;
	windPtr->windY = windVals.windY;
	windPtr->terrain = windVals.terrain;
	windPtr->windSpeed = windVals.windSpeed;
	windPtr->padding3 = windVals.padding3;
	deviceContext->Unmap(windBuffer, 0);
	deviceContext->GSSetConstantBuffers(1, 1, &windBuffer);
	deviceContext->PSSetConstantBuffers(0, 1, &windBuffer);
	deviceContext->VSSetConstantBuffers(1, 1, &windBuffer);


	deviceContext->Map(noiseBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	noisePtr = (NoiseValues*)mappedResource.pData;

	noisePtr->freq = noiseVals.freq;
	noisePtr->ampl = noiseVals.ampl;
	noisePtr->time = noiseVals.time;
	noisePtr->wobbleAmp = noiseVals.wobbleAmp;
	noisePtr->xOffset = noiseVals.xOffset;
	noisePtr->yOffset = noiseVals.yOffset;
	noisePtr->scrollX = noiseVals.scrollX;
	noisePtr->scrollY = noiseVals.scrollY;
	deviceContext->Unmap(noiseBuffer, 0);
	deviceContext->VSSetConstantBuffers(2, 1, &noiseBuffer);

	deviceContext->Map(camBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	camPtr = (CamBuff*)mappedResource.pData;

	camPtr->cameraPos = camPos;
	camPtr->padding = 0.f;
	camPtr->cameraRot = camRot;
	camPtr->padding2 = 0.f;

	deviceContext->Unmap(camBuffer, 0);
	deviceContext->GSSetConstantBuffers(2, 1, &camBuffer);
	deviceContext->GSSetShaderResources(0, 1, &height);
	deviceContext->GSSetShaderResources(1, 1, &blue);
	deviceContext->GSSetSamplers(0, 1, &sampleState);


	// Set shader texture and sampler resource in the pixel shader.
	deviceContext->PSSetShaderResources(0, 1, &texture);
	deviceContext->PSSetSamplers(0, 1, &sampleState);


	// Set shader texture and sampler resource in the pixel shader.
	deviceContext->VSSetShaderResources(0, 1, &height);
	//deviceContext->VSSetConstantBuffers(1, 1, &windBuffer);

	deviceContext->VSSetSamplers(0, 1, &sampleState);


}
