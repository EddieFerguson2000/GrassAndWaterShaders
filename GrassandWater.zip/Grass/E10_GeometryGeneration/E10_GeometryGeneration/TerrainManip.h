// Light shader.h
// Geometry shader example.
#pragma once

#include "DXF.h"
#include "ShaderStructs.h"
#include "BaseShader.h"

using namespace std;
using namespace DirectX;

class TerrainManip : public BaseShader
{
public:
	TerrainManip(ID3D11Device* device, HWND hwnd);
	~TerrainManip();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX& world, const XMMATRIX& view, const XMMATRIX& projection, ID3D11ShaderResourceView* texture, ID3D11ShaderResourceView* heightMap, ID3D11ShaderResourceView* grass, ID3D11ShaderResourceView* sand, ID3D11ShaderResourceView* rock, ID3D11ShaderResourceView* snow, ID3D11ShaderResourceView* water, ID3D11ShaderResourceView* darkSand, NoiseValues noise, TerrainValues ter);

private:
	void initShader(const wchar_t* vs, const wchar_t* ps);

private:
	ID3D11Buffer* matrixBuffer;
	ID3D11SamplerState* sampleState;
	ID3D11Buffer* noiseBuffer;
	ID3D11Buffer* terrainBuffer;
};

