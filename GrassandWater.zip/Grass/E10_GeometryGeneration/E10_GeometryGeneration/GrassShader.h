// Light shader.h
// Geometry shader example.
#pragma once

#include "DXF.h"
#include "ShaderStructs.h"

using namespace std;
using namespace DirectX;


class GrassShader : public BaseShader
{

public:

	GrassShader(ID3D11Device* device, HWND hwnd);
	~GrassShader();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX& world, const XMMATRIX& view, const XMMATRIX& projection, ID3D11ShaderResourceView* texture, Wind windVals, ID3D11ShaderResourceView* height, ID3D11ShaderResourceView* blue, XMFLOAT3 camPos, XMFLOAT3 camRot, NoiseValues noiseVals);

private:
	void initShader(const wchar_t* vsFilename, const wchar_t* psFilename);
	void initShader(const wchar_t* vsFilename, const wchar_t* gsFilename, const wchar_t* psFilename);


private:
	ID3D11Buffer* matrixBuffer;
	ID3D11Buffer* windBuffer;
	ID3D11Buffer* camBuffer;
	ID3D11Buffer* noiseBuffer;
};
