#include "TerrainManip.h"

TerrainManip::TerrainManip(ID3D11Device* device, HWND hwnd) : BaseShader(device, hwnd)
{
	initShader(L"TerrainManip_vs.cso", L"TerrainManip_ps.cso");
}


TerrainManip::~TerrainManip()
{
	// release the sampler state.
	if (sampleState)
	{
		sampleState->Release();
		sampleState = 0;
	}

	// release the matrix constant buffer.
	if (matrixBuffer)
	{
		matrixBuffer->Release();
		matrixBuffer = 0;
	}

	// release the terrain buffer
	if (terrainBuffer)
	{
		terrainBuffer->Release();
		terrainBuffer = 0;
	}

	// release noise buffer
	if (noiseBuffer)
	{
		noiseBuffer->Release();
		noiseBuffer = 0;
	}

	// Release the layout.
	if (layout)
	{
		layout->Release();
		layout = 0;
	}

	//Release base shader components
	BaseShader::~BaseShader();
}


void TerrainManip::initShader(const wchar_t* vsFilename, const wchar_t* psFilename)
{
	D3D11_BUFFER_DESC matrixBufferDesc;
	D3D11_SAMPLER_DESC samplerDesc;

	// Load (+ compile) shader files
	loadVertexShader(vsFilename);
	loadPixelShader(psFilename);

	// Setup the description of the dynamic matrix constant buffer that is in the vertex shader.
	matrixBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	matrixBufferDesc.ByteWidth = sizeof(MatrixBufferType);
	matrixBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	matrixBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	matrixBufferDesc.MiscFlags = 0;
	matrixBufferDesc.StructureByteStride = 0;

	// Create the constant buffer pointer so we can access the vertex shader constant buffer from within this class.
	renderer->CreateBuffer(&matrixBufferDesc, NULL, &matrixBuffer);


	// Setup noise variables buffer
	D3D11_BUFFER_DESC noiseBufferDesc;

	noiseBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	noiseBufferDesc.ByteWidth = sizeof(NoiseValues);
	noiseBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	noiseBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	noiseBufferDesc.MiscFlags = 0;
	noiseBufferDesc.StructureByteStride = 0;
	renderer->CreateBuffer(&noiseBufferDesc, NULL, &noiseBuffer);
	
	// Setup terrain buffer (is it just grass or not)
	D3D11_BUFFER_DESC terrainBufferDesc;

	terrainBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	terrainBufferDesc.ByteWidth = sizeof(TerrainValues);
	terrainBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	terrainBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	terrainBufferDesc.MiscFlags = 0;
	terrainBufferDesc.StructureByteStride = 0;
	renderer->CreateBuffer(&terrainBufferDesc, NULL, &terrainBuffer);

	// Create a texture sampler state description.
	samplerDesc.Filter = D3D11_FILTER_ANISOTROPIC;
	samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	samplerDesc.MipLODBias = 0.0f;
	samplerDesc.MaxAnisotropy = 1;
	samplerDesc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	samplerDesc.MinLOD = 0;
	samplerDesc.MaxLOD = D3D11_FLOAT32_MAX;

	// Create the texture sampler state.
	renderer->CreateSamplerState(&samplerDesc, &sampleState);

}


void TerrainManip::setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX& worldMatrix, const XMMATRIX& viewMatrix, const XMMATRIX& projectionMatrix, ID3D11ShaderResourceView* texture, ID3D11ShaderResourceView* heightMap, ID3D11ShaderResourceView* grass, ID3D11ShaderResourceView* sand, ID3D11ShaderResourceView* rock, ID3D11ShaderResourceView* snow, ID3D11ShaderResourceView* water, ID3D11ShaderResourceView* darkSand, NoiseValues noiseVals, TerrainValues ter)
{
	HRESULT result;
	D3D11_MAPPED_SUBRESOURCE mappedResource;
	MatrixBufferType* dataPtr;
	NoiseValues* noise;
	TerrainValues* terrain;
	XMMATRIX tworld, tview, tproj;


	// Transpose the matrices to prepare them for the shader.
	tworld = XMMatrixTranspose(worldMatrix);
	tview = XMMatrixTranspose(viewMatrix);
	tproj = XMMatrixTranspose(projectionMatrix);

	// Sned matrix data
	result = deviceContext->Map(matrixBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	dataPtr = (MatrixBufferType*)mappedResource.pData;
	dataPtr->world = tworld;// worldMatrix;
	dataPtr->view = tview;
	dataPtr->projection = tproj;
	deviceContext->Unmap(matrixBuffer, 0);
	deviceContext->VSSetConstantBuffers(0, 1, &matrixBuffer);
	deviceContext->VSSetShaderResources(0, 1, &heightMap);
	deviceContext->VSSetSamplers(0, 1, &sampleState);


	deviceContext->Map(noiseBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	noise = (NoiseValues*)mappedResource.pData;

	noise->freq = noiseVals.freq;
	noise->ampl = noiseVals.ampl;
	noise->time = noiseVals.time;
	noise->wobbleAmp = noiseVals.wobbleAmp;
	noise->xOffset = noiseVals.xOffset;
	noise->yOffset = noiseVals.yOffset;
	noise->scrollX = noiseVals.scrollX;
	noise->scrollY = noiseVals.scrollY;
	deviceContext->Unmap(noiseBuffer, 0);
	deviceContext->VSSetConstantBuffers(1, 1, &noiseBuffer);

	deviceContext->Map(terrainBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	terrain = (TerrainValues*)mappedResource.pData;

	terrain->terrainType = ter.terrainType;
	terrain->padding = 0.f;
	terrain->padding2 = 0.f;
	terrain->padding3 = 0.f;
	deviceContext->Unmap(terrainBuffer, 0);
	deviceContext->PSSetConstantBuffers(0, 1, &terrainBuffer);


	// Set shader texture and sampler resource in the pixel shader.
	deviceContext->PSSetShaderResources(0, 1, &grass);
	deviceContext->PSSetShaderResources(1, 1, &sand);
	deviceContext->PSSetShaderResources(2, 1, &rock);
	deviceContext->PSSetShaderResources(3, 1, &snow);
	deviceContext->PSSetShaderResources(4, 1, &water);
	deviceContext->PSSetShaderResources(5, 1, &darkSand);
	deviceContext->PSSetSamplers(0, 1, &sampleState);
}