#pragma once
//All the structs I need for passing info to shaders.
//Certainly not the best way to do this but I wanted to share some of
//these between shaders and this was the first thing I thought of
#include "DXF.h"

struct NoiseValues
{
	float freq;
	float ampl;
	float time;
	float wobbleAmp;
	float xOffset;
	float yOffset;
	float scrollX;
	float scrollY;
};

struct TerrainValues
{
	int terrainType;
	float padding;
	float padding2;
	float padding3;
};

struct CamBuff
{
	XMFLOAT3 cameraPos;
	float padding;
	XMFLOAT3 cameraRot;
	float padding2;
};

struct Wind
{
	float grassDisplacement = 3;
	float windFrequency = 0.1;
	float dt;
	float x;
	float y;
	float ballX;
	float ballY;
	float windX = 0.9;
	float windY = 0.2;
	int terrain;
	float windSpeed = 3;
	float padding3;
};

struct PositionValues
{
	float xPos;
	float yPos;
	float zOffset = 0.f;
	float padding = 0.f;
};

struct WaveValues
{
	float t;
	float x = 0.f;
	float y = 0.f;
	float s = 0.f;
	XMFLOAT4 wave11 = XMFLOAT4(1, 1, 0.25, 60);
	XMFLOAT4 wave12 = XMFLOAT4(20, 0, 0.1, 0.1);
	XMFLOAT4 wave21 = XMFLOAT4(1, 0.6, 0.25, 30);
	XMFLOAT4 wave22 = XMFLOAT4(2, 0, 0.1, 0.1);
	XMFLOAT4 wave31 = XMFLOAT4(1, 1.3, 0.5, 18);
	XMFLOAT4 wave32 = XMFLOAT4(3, 1, 7.5, 0.05);
};