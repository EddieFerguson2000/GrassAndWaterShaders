//This is what I use when I JUST want to load an object with a texture. no lighting or anything
//Used for ortho meshes and the sun

#include "BallPosShader.h"



BallPosShader::BallPosShader(ID3D11Device* device, HWND hwnd) : BaseShader(device, hwnd)
{
	initShader(L"texture_vs.cso", L"texture_ps.cso");
}


BallPosShader::~BallPosShader()
{
	// Release the sampler state.
	if (sampleState)
	{
		sampleState->Release();
		sampleState = 0;
	}

	// Release the matrix constant buffer.
	if (matrixBuffer)
	{
		matrixBuffer->Release();
		matrixBuffer = 0;
	}
	
	if (posBuffer)
	{
		posBuffer->Release();
		posBuffer = 0;
	}
	
	if (noiseBuffer)
	{
		noiseBuffer->Release();
		noiseBuffer = 0;
	}

	// Release the layout.
	if (layout)
	{
		layout->Release();
		layout = 0;
	}

	//Release base shader components
	BaseShader::~BaseShader();
}


void BallPosShader::initShader(const wchar_t* vsFilename, const wchar_t* psFilename)
{
	D3D11_BUFFER_DESC matrixBufferDesc;
	D3D11_SAMPLER_DESC samplerDesc;

	// Load (+ compile) shader files
	loadVertexShader(vsFilename);
	loadPixelShader(psFilename);

	// Setup the description of the dynamic matrix constant buffer that is in the vertex shader.
	matrixBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	matrixBufferDesc.ByteWidth = sizeof(MatrixBufferType);
	matrixBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	matrixBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	matrixBufferDesc.MiscFlags = 0;
	matrixBufferDesc.StructureByteStride = 0;
	// Create the constant buffer pointer so we can access the vertex shader constant buffer from within this class.
	renderer->CreateBuffer(&matrixBufferDesc, NULL, &matrixBuffer);

	// Setup position buffer
	D3D11_BUFFER_DESC posBufferDesc;

	posBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	posBufferDesc.ByteWidth = sizeof(PositionValues);
	posBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	posBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	posBufferDesc.MiscFlags = 0;
	posBufferDesc.StructureByteStride = 0;
	renderer->CreateBuffer(&posBufferDesc, NULL, &posBuffer);

	// Setup noise buffer
	D3D11_BUFFER_DESC noiseBufferDesc;

	noiseBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	noiseBufferDesc.ByteWidth = sizeof(NoiseValues);
	noiseBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	noiseBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	noiseBufferDesc.MiscFlags = 0;
	noiseBufferDesc.StructureByteStride = 0;
	renderer->CreateBuffer(&noiseBufferDesc, NULL, &noiseBuffer);


	// Create a texture sampler state description.
	samplerDesc.Filter = D3D11_FILTER_ANISOTROPIC;
	samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.MipLODBias = 0.0f;
	samplerDesc.MaxAnisotropy = 1;
	samplerDesc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	samplerDesc.MinLOD = 0;
	samplerDesc.MaxLOD = D3D11_FLOAT32_MAX;

	// Create the texture sampler state.
	renderer->CreateSamplerState(&samplerDesc, &sampleState);

}


void BallPosShader::setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX& worldMatrix, const XMMATRIX& viewMatrix, const XMMATRIX& projectionMatrix, ID3D11ShaderResourceView* texture, PositionValues pos, NoiseValues noise)
{
	HRESULT result;
	D3D11_MAPPED_SUBRESOURCE mappedResource;
	MatrixBufferType* dataPtr;
	PositionValues* posPtr;
	NoiseValues* noisePtr;
	XMMATRIX tworld, tview, tproj;




	// Transpose the matrices to prepare them for the shader.
	tworld = XMMatrixTranspose(worldMatrix);
	tview = XMMatrixTranspose(viewMatrix);
	tproj = XMMatrixTranspose(projectionMatrix);

	
	deviceContext->Map(matrixBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	dataPtr = (MatrixBufferType*)mappedResource.pData;
	dataPtr->world = tworld;// worldMatrix;
	dataPtr->view = tview;
	dataPtr->projection = tproj;
	deviceContext->Unmap(matrixBuffer, 0);
	deviceContext->VSSetConstantBuffers(0, 1, &matrixBuffer);



	deviceContext->Map(posBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	posPtr = (PositionValues*)mappedResource.pData;

	posPtr->xPos = pos.xPos;
	posPtr->yPos = pos.yPos;
	posPtr->zOffset = pos.zOffset;
	posPtr->padding = 0.f;
	deviceContext->Unmap(posBuffer, 0);
	deviceContext->VSSetConstantBuffers(1, 1, &posBuffer);


	deviceContext->Map(noiseBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	noisePtr = (NoiseValues*)mappedResource.pData;

	noisePtr->freq = noise.freq;
	noisePtr->ampl = noise.ampl;
	noisePtr->time = noise.time;
	noisePtr->wobbleAmp = noise.wobbleAmp;
	noisePtr->xOffset = noise.xOffset;
	noisePtr->yOffset = noise.yOffset;
	noisePtr->scrollX = noise.scrollX;
	noisePtr->scrollY = noise.scrollY;
	deviceContext->Unmap(noiseBuffer, 0);
	deviceContext->VSSetConstantBuffers(2, 1, &noiseBuffer);


	// Set shader texture and sampler resource in the pixel shader.
	deviceContext->PSSetShaderResources(0, 1, &texture);
	deviceContext->PSSetSamplers(0, 1, &sampleState);
}