#pragma once
#include "DXF.h"	// include dxframework
#include "GrassShader.h"
#include "SevenPointMesh.h"
#include "PerlinNoise.h"
#include "TerrainManip.h"
#include "ShaderStructs.h"
#include "BallPosShader.h"
#include "WaveShader.h"

class Island
{
public:
	Island();
	~Island();
	void init(TextureManager* texMan, D3D* renderTemp, HWND hwnd);
	void update(float dt);
	bool render(float dt, FPCamera* camera);
	void gui(float dt, D3D* renderer);

protected:

private:
	TerrainManip* terrainShader;
	GrassShader* grassShader;
	BallPosShader* ballShader;
	WaveShader* waveShader;
	SevenPointMesh* spm;
	PointMesh* mesh;
	PlaneMesh* planeMesh;
	PlaneMesh* waterMesh;
	SphereMesh* sphereMesh;
	TextureManager* textureMgr;
	D3D* renderer;
	Wind wind;
	PositionValues pos;
	NoiseValues noise;
	TerrainValues terrain;
	WaveValues waves;

	//These are for slightly randomizing the spawn locations of every possible tuft of grass (100*100 = 10000)
	float randGrassX[9999];
	float randGrassY[9999];


	int amountOfGrass = 100; // the number of tufts

	float time;

	int terrainType;
	float terrainHeight = 0;


	bool wireframe = false;
	bool waterVisible = true;
	bool landVisible = true;
	bool guiMenus[5];



};

