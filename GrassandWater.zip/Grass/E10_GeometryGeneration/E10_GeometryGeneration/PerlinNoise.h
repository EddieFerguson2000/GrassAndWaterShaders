#pragma once
class PerlinNoise
{
public:
	float snoise2(float x, float y);
};
