#pragma once

#include "BaseShader.h"
#include "ShaderStructs.h"

using namespace std;
using namespace DirectX;

class BallPosShader : public BaseShader
{
public:
	BallPosShader(ID3D11Device* device, HWND hwnd);
	~BallPosShader();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX& world, const XMMATRIX& view, const XMMATRIX& projection, ID3D11ShaderResourceView* texture, PositionValues pos, NoiseValues noise);

private:
	void initShader(const wchar_t* vs, const wchar_t* ps);

private:
	ID3D11Buffer* matrixBuffer;
	ID3D11Buffer* posBuffer;
	ID3D11Buffer* noiseBuffer;
	ID3D11SamplerState* sampleState;
};

