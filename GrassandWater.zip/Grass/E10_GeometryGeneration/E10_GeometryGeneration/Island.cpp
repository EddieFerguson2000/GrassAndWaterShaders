#include "Island.h"
Island::Island()
{

}

Island::~Island()
{

}

void Island::init(TextureManager* texMan, D3D* renderTemp, HWND hwnd)
{
	renderer = renderTemp;
	textureMgr = texMan;

	// Call super/parent init function (required!)
	//Textures
	textureMgr->loadTexture(L"grass", L"res/grass2.png");
	textureMgr->loadTexture(L"grassCrush", L"res/GrassCrush.png");
	textureMgr->loadTexture(L"grassHeight", L"res/GrassHeight.png");
	textureMgr->loadTexture(L"grassTerrain", L"res/Grassy4.png");
	textureMgr->loadTexture(L"sandTerrain", L"res/sandy.jpg");
	textureMgr->loadTexture(L"snowTerrain", L"res/snow.jpg");
	textureMgr->loadTexture(L"water", L"res/water.jpg");
	textureMgr->loadTexture(L"rockTerrain", L"res/mountain.jpg");
	textureMgr->loadTexture(L"height", L"res/height.png");


	// Create Mesh objects
	mesh = new PointMesh(renderTemp->getDevice(), renderTemp->getDeviceContext());
	spm = new SevenPointMesh(renderTemp->getDevice(), renderTemp->getDeviceContext());
	planeMesh = new PlaneMesh(renderTemp->getDevice(), renderTemp->getDeviceContext());
	waterMesh = new PlaneMesh(renderTemp->getDevice(), renderTemp->getDeviceContext());
	sphereMesh = new SphereMesh(renderTemp->getDevice(), renderTemp->getDeviceContext());
	

	//Init shaders
	grassShader = new GrassShader(renderTemp->getDevice(), hwnd);
	ballShader = new BallPosShader(renderTemp->getDevice(), hwnd);
	waveShader = new WaveShader(renderTemp->getDevice(), hwnd);
	terrainShader = new TerrainManip(renderTemp->getDevice(), hwnd);

	//Slightly randomised tuft of grass location
	for (int i = 0; i < 9999; i++)
	{
		randGrassX[i] = rand() % 100;
		randGrassX[i] -= 50;
		randGrassX[i] /= 100;
		randGrassY[i] = rand() % 100;
		randGrassY[i] -= 50;
		randGrassY[i] /= 100;
	}
	time = 0.f;
}

void Island::update(float dt)
{
	if (time < 0) { time = 0; }
	else { time += dt; }

	pos.xPos = wind.ballX;
	pos.yPos = wind.ballY;

	waves.t = time;
	wind.dt = time;
	noise.time = time;

	terrain.terrainType = terrainType;
	wind.terrain = terrainType;
}



bool Island::render(float dt, FPCamera* camera)
{

	renderer->setWireframeMode(wireframe);
	// Get the world, view, projection, and ortho matrices from the camera and Direct3D objects.
	XMMATRIX worldMatrix = renderer->getWorldMatrix();
	XMMATRIX viewMatrix = camera->getViewMatrix();
	XMMATRIX projectionMatrix = renderer->getProjectionMatrix();
	XMMATRIX translateMatrix = XMMatrixTranslation(0, 0, 0);
	XMMATRIX scaleMatrix = XMMatrixScaling(1, 1, 1);
	XMMATRIX rotateMatrix = XMMatrixRotationRollPitchYaw(0, 0, 0);


	// Send geometry data, set shader parameters, render object with shader
	//mesh->sendData(renderer->getDeviceContext());
	worldMatrix = renderer->getWorldMatrix();
	translateMatrix = XMMatrixTranslation(0, terrainHeight, 0);
	worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);

	if (landVisible)
	{
		planeMesh->sendData(renderer->getDeviceContext());
		terrainShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"grass"), textureMgr->getTexture(L"height"), textureMgr->getTexture(L"grassTerrain"), textureMgr->getTexture(L"sandTerrain"), textureMgr->getTexture(L"rockTerrain"), textureMgr->getTexture(L"snowTerrain"), textureMgr->getTexture(L"water"), textureMgr->getTexture(L"sandTerrain"), noise, terrain);
		terrainShader->render(renderer->getDeviceContext(), planeMesh->getIndexCount());

		//Try to spread the grass evenly across the plane
		float amountVar;
		if (amountOfGrass > 0)
		{
			amountVar = 100.f / (float)amountOfGrass;
		}

		// runs for every tuft of grass
		// Must be a more efficient way of doing this but I don't have the KNOWLEDGE yet
		for (int i = amountOfGrass; i > 0; i--)
		{
			for (int j = amountOfGrass - 1; j > 0; j--)
			{
				int iTemp = i * amountVar;
				int jTemp = j * amountVar;
				translateMatrix = XMMatrixTranslation(iTemp + (randGrassX[iTemp * jTemp] * amountVar), terrainHeight, jTemp + (randGrassY[iTemp * jTemp] * amountVar));
				worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);

				spm->sendData(renderer->getDeviceContext());
				wind.x = iTemp;
				wind.y = jTemp;
				grassShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"grass"), wind, textureMgr->getTexture(L"grassCrush"), textureMgr->getTexture(L"grassHeight"), camera->getPosition(), camera->getRotation(), noise);
				grassShader->render(renderer->getDeviceContext(), spm->getIndexCount());
				worldMatrix = renderer->getWorldMatrix();
			}
		}

		renderer->setAlphaBlending(true);
		worldMatrix = renderer->getWorldMatrix();

		scaleMatrix = XMMatrixScaling(2, 2, 2);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		translateMatrix = XMMatrixTranslation(3.5 + (pos.xPos * 10), 2.f + terrainHeight, 3.5 + (pos.yPos * 10));
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);

		//This ball is really only here to bring attention to the fact that grass can be spread around it
		sphereMesh->sendData(renderer->getDeviceContext());
		ballShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"sandTerrain"), pos, noise);
		ballShader->render(renderer->getDeviceContext(), sphereMesh->getIndexCount());
		renderer->setAlphaBlending(false);
	}
	if (waterVisible)
	{
		renderer->setAlphaBlending(true);
		worldMatrix = renderer->getWorldMatrix();
		translateMatrix = XMMatrixTranslation(0, -7.f, 0);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		waterMesh->sendData(renderer->getDeviceContext());
		waveShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"water"), waves);
		waveShader->render(renderer->getDeviceContext(), waterMesh->getIndexCount());

		renderer->setAlphaBlending(false);
	}

	// Render GUI
	gui(dt, renderer);
	return true;
}

void Island::gui(float dt, D3D* renderer)
{
	// Force turn off unnecessary shader stages.
	renderer->getDeviceContext()->GSSetShader(NULL, NULL, 0);
	renderer->getDeviceContext()->HSSetShader(NULL, NULL, 0);
	renderer->getDeviceContext()->DSSetShader(NULL, NULL, 0);

	if (guiMenus[0]) // menu for all the grass related stuff
	{
		ImGui::Begin("Grass");
		ImGui::SliderInt("Amount Of Grass", &amountOfGrass, 0, 100);
		ImGui::SliderFloat("Wind Speed", &wind.windSpeed, -5, 5);
		ImGui::SliderFloat("Wind Frequency", &wind.windFrequency, 0, 1);
		ImGui::SliderFloat("windX", &wind.windX, -1, 1);
		ImGui::SliderFloat("windY", &wind.windY, -1, 1);
		ImGui::SliderFloat("Ball Position X", &wind.ballX, 0, 9);
		ImGui::SliderFloat("Ball Position Y", &wind.ballY, 0, 9);
		ImGui::SliderFloat("Grass Displacement", &wind.grassDisplacement, -10, 10);
		ImGui::End();
	}
	
	if (guiMenus[1]) // all the terrain based stuff
	{
		ImGui::Begin("Land");
		ImGui::SliderFloat("Terrain yPos", &terrainHeight, -10, 10);
		ImGui::SliderFloat("Noise Freq", &noise.freq, -5, 5);
		ImGui::SliderFloat("Noise Amp", &noise.ampl, 0, 25);
		ImGui::SliderFloat("Wobble Amp", &noise.wobbleAmp, -1, 1);
		ImGui::SliderFloat("X Offset", &noise.xOffset, -100, 100);
		ImGui::SliderFloat("Y Offset", &noise.yOffset, -100, 100);
		ImGui::SliderFloat("X Scroll", &noise.scrollX, -1, 1);
		ImGui::SliderFloat("Y Scroll", &noise.scrollY, -1, 1);
		ImGui::SliderInt("Terrain Type", &terrainType, 0, 1);
		ImGui::End();
	}

	if (guiMenus[2]) // and the water. This is three menus, as you are combining three waves together when you use this
	{
		//Waves
		ImGui::Begin("Wave 1");
		ImGui::SliderFloat("X Direction 1", &waves.wave11.x, -5, 5);
		ImGui::SliderFloat("Z Direction 1", &waves.wave11.y, -5, 5);
		ImGui::SliderFloat("Steepness 1", &waves.wave11.z, 0, 1);
		ImGui::SliderFloat("Wavelength 1", &waves.wave11.w, -100, 100);
		ImGui::SliderFloat("Wave Speed 1", &waves.wave12.x, 0, 100);
		ImGui::SliderFloat("Use Noise 1", &waves.wave12.y, 0, 1);
		ImGui::SliderFloat("Noise Amplitude 1", &waves.wave12.z, 0, 10);
		ImGui::SliderFloat("Noise Speed 1", &waves.wave12.w, -10, 10);
		ImGui::End();
		ImGui::Begin("Wave 2");
		ImGui::SliderFloat("X Direction 2", &waves.wave21.x, -5, 5);
		ImGui::SliderFloat("Z Direction 2", &waves.wave21.y, -5, 5);
		ImGui::SliderFloat("Steepness 2", &waves.wave21.z, 0, 1);
		ImGui::SliderFloat("Wavelength 2", &waves.wave21.w, -100, 100);
		ImGui::SliderFloat("Wave Speed 2", &waves.wave22.x, 0, 100);
		ImGui::SliderFloat("Use Noise 2", &waves.wave22.y, 0, 1);
		ImGui::SliderFloat("Noise Amplitude 2", &waves.wave22.z, 0, 10);
		ImGui::SliderFloat("Noise Speed 2", &waves.wave22.w, -10, 10);
		ImGui::End();
		ImGui::Begin("Wave 3");
		ImGui::SliderFloat("X Direction 3", &waves.wave31.x, -5, 5);
		ImGui::SliderFloat("Z Direction 3", &waves.wave31.y, -5, 5);
		ImGui::SliderFloat("Steepness 3", &waves.wave31.z, 0, 1);
		ImGui::SliderFloat("Wavelength 3", &waves.wave31.w, -100, 100);
		ImGui::SliderFloat("Wave Speed 3", &waves.wave32.x, 0, 100);
		ImGui::SliderFloat("Use Noise 3", &waves.wave32.y, 0, 1);
		ImGui::SliderFloat("Noise Amplitude 3", &waves.wave32.z, 0, 10);
		ImGui::SliderFloat("Noise Speed 3", &waves.wave32.w, -10, 10);
		ImGui::End();
	}

	//Main menu
	ImGui::Begin("Scene Control");
	ImGui::Text("FPS: %.2f", 1 / dt);
	ImGui::Checkbox("Wireframe mode", &wireframe);
	ImGui::Checkbox("Water Visible", &waterVisible);
	ImGui::Checkbox("Land Visible", &landVisible);
	ImGui::Checkbox("Grass Menu", &guiMenus[0]);
	ImGui::Checkbox("Land Menu", &guiMenus[1]);
	ImGui::Checkbox("Water Menus", &guiMenus[2]);
	ImGui::End();

	// Render UI
	ImGui::Render();
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}