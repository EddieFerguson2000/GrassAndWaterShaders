# CMP301_GeometryGeneration
Starter project for CMP301. Geometry shader and generation example.

Name:

Number:

Outline of project:
